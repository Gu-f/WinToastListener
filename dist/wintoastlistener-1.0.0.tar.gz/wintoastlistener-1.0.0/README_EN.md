# WinToastListener
A python library implemented by python3, for listening to Toast message notifications on windows.
  
